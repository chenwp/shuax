#include <stdio.h>
#include <windows.h>
int main()
{
    system("CLS");
    char s[1024];
    char name[16];
    FILE *fp;
    float a,b;
    long long sum=0;
	for(int g=0;g<1000;g++)
	{
		wsprintf(name,"%d.txt",g+1);
		
		fp=fopen(name,"rb");
		
		char ch;
		a=b=0;
		
		for(int i=0;i<18;i++)
		{
			while(1)
		   {
				ch=fgetc(fp);
				if(ch==0x0d)
				{
					fgetc(fp);
					fgetc(fp);
					break;
				}
				//putchar(ch);
			}
		}
		fgets(s,20,fp);
		fgets(s,1023,fp);
		s[strlen(s)-6]=0;
		puts(s);
		//sscanf(s,"%f,%f",&a,&b);
		//printf("%.6f %.6f\n",a,b);
		fclose(fp);
	}
	getchar();
	//printf("%lf\n",sum);
}
