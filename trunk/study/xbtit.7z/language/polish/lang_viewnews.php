<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language["POSTED_BY"]   = "Napisany przez";
$language["POSTED_DATE"] = "Data";
$language["TITLE"]       = "Tytuł";
$language["ADD"]         = "Dodaj";

?>
