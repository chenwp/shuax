<?php
$language["INSERT_USERNAME"]="Musisz wpisać nick!";
$language["INSERT_PASSWORD"]="Musisz wpisać hasło!";
?>