<?php
$language["ACCOUNT_CREATED"]="Konto utworzone";
$language["USER_NAME"]="User";
$language["USER_PWD_AGAIN"]="Powtórz hasło";
$language["USER_PWD"]="Hasło";
$language["USER_STYLE"]="Styl";
$language["USER_LANGUE"]="Język";
$language["IMAGE_CODE"]="Kod obrazka";
$language["INSERT_USERNAME"]="Musisz wpisać nick!";
$language["INSERT_PASSWORD"]="Musisz wpisać hasło!";
$language["DIF_PASSWORDS"]="Hasła nie pasuj±!";
$language["ERR_NO_EMAIL"]="Musisz wprowadzić prawidłowy adres email";
$language["USER_EMAIL_AGAIN"]="Powtórz email";
$language["ERR_NO_EMAIL_AGAIN"]="Powtórz email";
$language["DIF_EMAIL"]="Adresy email nie pasuj±!";
$language["SECURITY_CODE"]="Odpowiedz na pytanie";
# Password strength
$language["WEEK"]="Słabe";
$language["MEDIUM"]="¦rednie";
$language["SAFE"]="Bezpieczne";
$language["STRONG"]="Mocne";

?>