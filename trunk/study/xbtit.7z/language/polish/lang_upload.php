<?php
$language["NOT_SHA"]="Brak funkcji SHA1. Musisz mieć PHP 4.3.0 lub nowszy.";
$language["NOT_AUTHORIZED_UPLOAD"]="Nie masz uprawnień do wstawiania torrentów!";
$language["FILE_UPLOAD_ERROR_1"]="Nie można odczytać wysłanego pliku";
$language["FILE_UPLOAD_ERROR_3"]="Plik ma zerowy rozmiar";
$language["FACOLTATIVE"]="opcjonalnie";
$language["FILE_UPLOAD_ERROR_2"]="Błąd uploadu pliku";
$language["ERR_PARSER"]="W twoim torrencie wystąpiły pewne błędy. Parser go nie zaakceptował.";
$language["WRITE_CATEGORY"]="Musisz wybrać kategorię torrenta...";
$language["DOWNLOAD"]="Pobierz";
$language["MSG_UP_SUCCESS"]="Upload pomyślny! Torrent został dodany.";
$language["MSG_DOWNLOAD_PID"]="PID system aktywny, pobierz torrenta ze swoim PID";
$language["EMPTY_DESCRIPTION"]="Musisz dodać opis pozycji!";
$language["EMPTY_ANNOUNCE"]="Announce jest pusty";
$language["FILE_UPLOAD_ERROR_1"]="Nie można odczytać wysłanego pliku";
$language["FILE_UPLOAD_ERROR_2"]="Błąd wysyłania pliku";
$language["FILE_UPLOAD_ERROR_3"]="Plik ma rozmiar 0 bajtów";
$language["NO_SHA_NO_UP"]="Uploadowanie plików niemożliwe - brak funkcji SHA1.";
$language["NOT_SHA"]="Brak funkcji SHA1. Musisz mieć PHP 4.3.0 lub nowsze.";
$language["ERR_PARSER"]="W twoim torrencie najprawdopodobniej wystąpił jakiś błąd. Parser go nie zaakceptował.";
$language["WRITE_CATEGORY"]="Musisz podać kategorię torrenta...";
$language["ERR_HASH"]="Info hash MUSI mieć dokładnie 40 hex bajtów.";
$language["ERR_EXTERNAL_NOT_ALLOWED"]="Zewnętrzne torrenty niedozwolone";
$language["ERR_MOVING_TORR"]="Błąd przenoszenia torrenta...";
$language["ERR_ALREADY_EXIST"]="Ten torrent już istnieje w naszej bazie danych.";
$language["MSG_DOWNLOAD_PID"]="PID system aktywny pobierz swojego torrenta ze swoim PID";
$language["MSG_UP_SUCCESS"]="Upload pomyślny! Torrent został dodany.";

?>