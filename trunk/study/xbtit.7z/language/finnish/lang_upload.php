<?php
$language["NOT_SHA"]="SHA1 Toiminto ei ole k&auml;ytett&auml;viss&auml;. Tarvitset PHP 4.3.0 tai uudemman.";
$language["NOT_AUTHORIZED_UPLOAD"]="Sinulla ei ole oikeutta julkaista torrentteja!";
$language["FILE_UPLOAD_ERROR_1"]="Ei voi lukea julkaistua tiedostoa";
$language["FILE_UPLOAD_ERROR_3"]="Tiedostolla ei ole kokoa";
$language["FACOLTATIVE"]="optional";
$language["FILE_UPLOAD_ERROR_2"]="Tiedoston lis&auml;ysvirhe";
$language["ERR_PARSER"]="Torrentissasi vaikuttaisi olevan virhe. Parser ei hyv&auml;ksynyt sit&auml;.";
$language["WRITE_CATEGORY"]="Sinun pit&auml;&auml; asettaa kategoria...";
$language["DOWNLOAD"]="Lataus";
$language["MSG_UP_SUCCESS"]="Julkaiseminen onnistui! Torrent lis&auml;tty.";
$language["MSG_DOWNLOAD_PID"]="PID-j&auml;rjestelm&auml; aktiivinen, lataa torrenttisi omalla PIDill&auml;si";
$language["EMPTY_DESCRIPTION"]="Sinun pit&auml;&auml; lis&auml;t&auml; kuvaus!";
$language["EMPTY_ANNOUNCE"]="Announce-osoite on tyhj&auml;";
$language["FILE_UPLOAD_ERROR_1"]="Ei voitu lukea lis&auml;tty&auml; tiedostoa";
$language["FILE_UPLOAD_ERROR_2"]="Tiedoston lis&auml;ysvirhe";
$language["FILE_UPLOAD_ERROR_3"]="Tiedostolla ei ole kokoa";
$language["NO_SHA_NO_UP"]="Tiedoston lis&auml;&auml;minen ei ole k&auml;ytett&auml;viss&auml; - ei SHA1 toimintoa.";
$language["NOT_SHA"]="SHA1 Toiminto ei ole k&auml;ytett&auml;viss&auml;. Tarvitset PHP 4.3.0 tai uudemman.";
$language["ERR_PARSER"]="Vaikuttaa silt&auml; ett&auml; torrentissa oli virhe. Parser ei hyv&auml;ksynyt sit&auml;.";
$language["WRITE_CATEGORY"]="Sinun pit&auml;&auml; asettaa kategoria...";
$language["ERR_HASH"]="Info hashin T&Auml;YTYY olla tarkalleen 40 hex tavua.";
$language["ERR_EXTERNAL_NOT_ALLOWED"]="Ulkoset torrentit ei ole sallittuja";
$language["ERR_MOVING_TORR"]="VIRHE torrentin siirrossa...";
$language["ERR_ALREADY_EXIST"]="T&auml;m&auml; torrentti on jo tietokannassa.";
$language["MSG_DOWNLOAD_PID"]="PID-j&auml;rjestelm&auml; aktiivinen, lataa torrent omalla PIDill&auml;si samaan kansioon miss� jaettava tiedosto sijaitsee";
$language["MSG_UP_SUCCESS"]="Julkaiseminen onnistunut! Torrentti lis&auml;tty.";

?>