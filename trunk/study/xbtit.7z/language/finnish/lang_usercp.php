<?php
$language["DELETE_READED"]="Poista";
$language["USER_LANGUE"]="Kieli";
$language["USER_STYLE"]="Teema";
$language["CURRENTLY_PEER"]="Sin&auml; l&auml;het&auml;t tai lataat t&auml;ll&auml; hetkell&auml; torrenttia.";
$language["STOP_PEER"]="Sinun pit&auml;&auml; pys&auml;ytt&auml;&auml; client.";
$language["USER_PWD_AGAIN"]="Toista salasana";
$language["EMAIL_FAILED"]="S&auml;hk&ouml;postin l&auml;hett&auml;minen ep&auml;onnistui!";
$language["NO_SUBJECT"]="Ei aihetta";
$language["MUST_ENTER_PASSWORD"]="<br /><font color='#FF0000'><strong>Sy&ouml;t&auml; salasana jotta asetukset tallentuvat.</strong></font>";
$language["ERR_PASS_WRONG"]="Salasana v&auml;&auml;rin, profiilia ei p&auml;ivitetty.";
$language["MSG_DEL_ALL_PM"]="Vain luetut viestit voidaan poistaa";
$language["ERR_PM_GUEST"]="Et voi l&auml;hett&auml;&auml; yksityisviesti&auml; vieraalle tai itsellesi!";
?>