<?php
$language["ACCOUNT_CREATED"]="K&auml;ytt&auml;j&auml;tunnus luotu";
$language["USER_NAME"]="K&auml;ytt&auml;j&auml;nimi";
$language["USER_PWD_AGAIN"]="Toista salasana";
$language["USER_PWD"]="Salasana";
$language["USER_STYLE"]="Teema";
$language["USER_LANGUE"]="Kieli";
$language["IMAGE_CODE"]="Kuvakoodi";
$language["INSERT_USERNAME"]="Sinun on pakko asettaa k&auml;ytt&auml;j&auml;nimi!";
$language["INSERT_PASSWORD"]="Sinun on pakko asettaa salasana!";
$language["DIF_PASSWORDS"]="Salasanat eiv&auml;t t&auml;sm&auml;&auml;!";
$language["ERR_NO_EMAIL"]="Sinun pit&auml;&auml; antaa toimiva s&auml;hk&ouml;postiosoite";
$language["USER_EMAIL_AGAIN"]="Toista s&auml;hk&ouml;postiosoite";
$language["ERR_NO_EMAIL_AGAIN"]="Toista s&auml;hk&ouml;postiosoite";
$language["DIF_EMAIL"]="S&auml;hk&ouml;postiosoitteet eiv&auml;t t&auml;sm&auml;&auml;!";
$language["SECURITY_CODE"]="Vastaa kysymykseen";
# Salasanan vahvuus
$language["WEEK"]="Heikko";
$language["MEDIUM"]="Keskivahva";
$language["SAFE"]="Turvallinen";
$language["STRONG"]="Vahva";

?>