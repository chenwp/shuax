<?php

// Translated to Vietnamese Language by VoTienSinh  & ThanhThanh for www.diemthuy.nl

$language["PEER_PROGRESS"]=" s&#7921; ti&#7871;n h&#224;nh ";
$language["PEER_COUNTRY"]="qu&#7889;c gia";  
$language["PEER_PORT"]="c&#7893;ng, c&#7917;a";
$language["PEER_STATUS"]=" t&#236;nh tr&#7841;ng";
$language["PEER_CLIENT"]=" ng&#432;&#7901;i tham d&#7921; ";
$language["NO_PEERS"]=" kh&#244;ng c&#243; ng&#432;&#7901;i tham d&#7921; ";
?>