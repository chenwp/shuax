<?php

// Translated to Vietnamese Language by VoTienSinh  & ThanhThanh for www.diemthuy.nl

$language["FIND_USER"]       = "T&#236;m ki&#7871;m th&#224;nh vi&#234;n";        
$language["USER_LEVEL"]      = "C&#7845;p b&#7853;t th&#224;nh vi&#234;n";      
$language["ALL"]             = "T&#7845;t C&#7843;";        
$language["SEARCH"]          = "T&#236;m ki&#7871;m";         
$language["USER_NAME"]       = "T&#234;n th&#224;nh vi&#234;n";      
$language["USER_JOINED"]     = "&#273;&#259;ng k&#253; v&#224;o ng&#224;y";     
$language["USER_LASTACCESS"] = "tr&#7921;c tuy&#7871;n l&#7847;n cu&#7889;i";        
$language["USER_COUNTRY"]    = "Qu&#7889;c gia";        
$language["RATIO"]           = "t&#7927; l&#7879;";         
$language["USERS_PM"]        = "th&#432; c&#225; nh&#226;n";         
$language["EDIT"]            = "thay &#273;&#7893;i";      
$language["DELETE"]          = "x&#243;a b&#7887;";       
$language["NO_USERS_FOUND"]  = "kh&#244;ng t&#236;m &#273;&#432;&#7907;c th&#224;nh vi&#234;n";  
$language["UNKNOWN"]         = "kh&#244;ng bi&#7871;t";        

?>