<?php

// Translated to Vietnamese Language by VoTienSinh  & ThanhThanh for www.diemthuy.nl

$language["PEER_PROGRESS"]=" ti&#7871;n h&#224;nh, ph&#225;t tri&#7875;n ";
$language["PEER_COUNTRY"]="qu&#7889;c gia";
$language["PEER_PORT"]="c&#7893;ng, c&#7917;a";
$language["PEER_STATUS"]="t&#236;nh tr&#7841;ng";
$language["PEER_CLIENT"]="th&#224;nh vi&#234;n, ng&#432;&#7901;i tham d&#7921;";
$language["NO_HISTORY"]="kh&#244;ng c&#243; l&#7883;ch s&#7917;";  
?>