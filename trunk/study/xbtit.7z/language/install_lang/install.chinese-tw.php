<?php
/////////////////////////////////////////////////////////////////////////////////////
// xbtit - Bittorrent tracker/frontend
//
// Copyright (C) 2004 - 2007  Btiteam
//
//    This file is part of xbtit.
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   1. Redistributions of source code must retain the above copyright notice,
//      this list of conditions and the following disclaimer.
//   2. Redistributions in binary form must reproduce the above copyright notice,
//      this list of conditions and the following disclaimer in the documentation
//      and/or other materials provided with the distribution.
//   3. The name of the author may not be used to endorse or promote products
//      derived from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
// WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
// IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
////////////////////////////////////////////////////////////////////////////////////

// english installation file //

$install_lang["charset"]                = "UTF-8";
$install_lang["lang_rtl"]               = FALSE;
$install_lang["step"]                   = "步驟:";
$install_lang["welcome_header"]         = "歡迎";
$install_lang["welcome"]                = "歡迎您安裝新的 xbtit ";
$install_lang["installer_language"]     = "語言:";
$install_lang["installer_language_set"] = "啟用此語言";
$install_lang["start"]                  = "開始";
$install_lang["next"]                   = "下一步";
$install_lang["back"]                   = "返回";
$install_lang["requirements_check"]     = "檢查需求";
$install_lang["reqcheck"]               = "檢查需求";
$install_lang["settings"]               = "設置";
$install_lang["system_req"]             = "<p>".$GLOBALS["btit-tracker"]."&nbsp;".$GLOBALS["current_btit_version"]." 需 PHP 4.1.2 或以上版本及 MYSQL 數據庫.</p>";
$install_lang["list_chmod"]             = "<p>在進下一步前, 請確認所有文件已上傳完畢, 及設置下述文件為可讀寫 (應設 0777 才行).</p>";
$install_lang["view_log"]               = "你能查看全部的更新日誌";
$install_lang["here"]                   = "這裡";
$install_lang["settingup"]              = "設置你的tracker";
$install_lang["settingup_info"]         = "基本設置";
$install_lang["sitename"]               = "網站名稱";
$install_lang["sitename_input"]         = "xbtit";
$install_lang["siteurl"]                = "網站網址";
$install_lang["siteurl_info"]           = "結尾不要加斜線";
$install_lang["mysql_settings"]         = "MySQL 設置<br />\n建立 MySQL 用戶和數據庫, 並在這輸入信息";
$install_lang["mysql_settings_info"]    = "數據庫設置";
$install_lang["mysql_settings_server"]  = "MySQL 伺服 (localhost works ok for most servers)";
$install_lang["mysql_settings_username"] = "MySQL 用戶名稱";
$install_lang["mysql_settings_password"] = "MySQL 用戶密碼";
$install_lang["mysql_settings_database"] = "MySQL 數據庫名稱";
$install_lang["mysql_settings_prefix"]  = "MySQL Table 前綴";
$install_lang["cache_folder"]           = "cache 目錄";
$install_lang["torrents_folder"]        = "torrents 目錄";
$install_lang["badwords_file"]          = "badwords.txt";
$install_lang["chat.php"]               = "chat.php";
$install_lang["write_succes"]           = "<span style=\"color:#00FF00; font-weight: bold;\">是可寫!</span>";
$install_lang["write_fail"]             = "<span style=\"color:#FF0000; font-weight: bold;\">不可寫!</span> (0777)";
$install_lang["write_file_not_found"]   = "<span style=\"color:#FF0000; font-weight: bold;\">找不到!</span>";
$install_lang["mysqlcheck"]             = "MySQL 連接檢查";
$install_lang["mysqlcheck_step"]        = "MySQL 檢查";
$install_lang["mysql_succes"]           = "<span style=\"color:#00FF00; font-weight: bold;\">連接數據庫成功!</span>";
$install_lang["mysql_fail"]             = "<span style=\"color:#FF0000; font-weight: bold;\">失敗, 無法連接數據庫!</span>";
$install_lang["back_to_settings"]       = "返回並填寫必要的信息";
$install_lang["saved"]                  = "保存";
$install_lang["file_not_writeable"]     = "這文件 <b>./include/settings.php</b> 不可寫.";
$install_lang["file_not_exists"]        = "這文件 <b>./include/settings.php</b> 不存在.";
$install_lang["not_continue_settings"]  = "您不能繼續安裝,這個文件沒有被寫入.";
$install_lang["not_continue_settings2"] = "你不能繼續此文件.";
$install_lang["settings.php"]           = "./include/settings.php";
$install_lang["can_continue"]           = "您可以繼續並稍後再進行此變更";
$install_lang["mysql_import"]           = "MySQL 輸入";
$install_lang["mysql_import_step"]      = "SQL 導入";
$install_lang["create_owner_account"]   = "創建站長帳戶";
$install_lang["create_owner_account_step"] = "創建站長";
$install_lang["database_saved"]         = "database.sql 已被導入至你的數據庫.";
$install_lang["create_owner_account_info"] = "你能在這建立站長帳戶";
$install_lang["username"]               = "名稱";
$install_lang["password"]               = "密碼";
$install_lang["password2"]              = "重覆密碼";
$install_lang["email"]                  = "Email";
$install_lang["email2"]                 = "重覆email";
$install_lang["is_succes"]              = "完畢.";
$install_lang["no_leave_blank"]         = "不要留下任何空白.";
$install_lang["not_valid_email"]        = "不確的 email 地址.";
$install_lang["pass_not_same_username"] = "密碼不可以和用戶名一樣.";
$install_lang["email_not_same"]         = "Email 地址錯誤.";
$install_lang["pass_not_same"]          = "密碼錯誤.";
$install_lang["site_config"]            = "Tracker 設置";
$install_lang["site_config_step"]       = "Tracker 設置";
$install_lang["default_lang"]           = "預設語言";
$install_lang["default_style"]          = "預設風格";
$install_lang["torrents_dir"]           = "Torrents 目錄";
$install_lang["validation"]             = "E-mail 驗證模式";
$install_lang["more_settings"]          = "*&nbsp;&nbsp;&nbsp;當安裝完成後,更多設置在 <u>系統面板</u> .";
$install_lang["tracker_saved"]          = "設置被保存.";
$install_lang["finished"]               = "Rounding up the Installation";
$install_lang["finished_step"]          = "Rounding up";
$install_lang["succes_install1"]        = "安裝已完成!";
$install_lang["succes_install2a"]       = "<p>你已成功安裝 ".$GLOBALS["btit-tracker"]." ".$GLOBALS["current_btit_version"].".</p><p>, 安裝已被鎖定成功和 <b>install.php</b> 被刪除, 防止再被安裝一次.</p>";
$install_lang["succes_install2b"]       = "<p>你已成功安裝  ".$GLOBALS["btit-tracker"]." ".$GLOBALS["current_btit_version"].".</p><p>, 我們建議您做鎖定安裝. 你可將 <b>install.unlock</b> 改為 <b>install.lock</b> 及刪除 <b>install.php</b> 文件.</p>";
$install_lang["succes_install3"]        = "<p>BTITeam 希望您喜歡使用本產品及參觀我們的 <a href=\"http://www.btiteam.org/smf/index.php\" target=\"_blank\">論壇</a>.</p>";
$install_lang["go_to_tracker"]          = "進入您的 tracker 網站";
$install_lang["forum_type"]             = "論壇型式";
$install_lang["forum_internal"]         = "xbtit 內部論壇";
$install_lang["forum_smf"]              = "smf 論壇";
$install_lang["forum_other"]            = "其它論壇 - 在這輸入網址 -->";
$install_lang["smf_download_a"]         = "<strong>如果使用SMF論壇:</strong><br /><br/ >請下載smf論壇最新版本 <a target='_new' href='http://www.simplemachines.org/download/'>這裡</a> 且上載好文件並將目錄名稱改為 \"smf\" 及 <a target='_new' href='smf/install.php'>點這</a> 安裝它.*<br /><strong>(請使用相同數據庫用於此安裝過程).<br /><br /><font color='#FF0000'>第一次安裝</font></strong> 請將 SMF English 的語言文件 (<strong>";
$install_lang["smf_download_b"]         = "</strong>) CHMOD to 777 後點擊 <strong>下一步</strong> 才能繼續安裝 xbtit.<br /><br /><strong>* 這兩個連結將在另一個新視窗打開,防止你丟失 xbiti 安裝.</strong></p>";
$install_lang["smf_err_1"]              = "在 \"smf\" 目錄找不到 smf 論壇, 請安裝它在繼續.<br /><br />點擊 <a href=\"javascript: history.go(-1);\">這裡</a> 返回到前一頁.";
$install_lang["smf_err_2"]              = "數據庫內找不到 smf 論壇, 請安裝它在繼續.<br /><br />點擊 <a href=\"javascript: history.go(-1);\">這裡</a> 返回到前一頁.";
$install_lang["smf_err_3a"]             = "不能寫入 SMF 語言文件 (<strong>";
$install_lang["smf_err_3b"]             = "</strong>) 請 CHMOD to 777 在繼續.<br /><br />點擊 <a href=\"javascript: history.go(-1);\">這裡</a> 返回到前一頁.";
$install_lang["allow_url_fopen"]        = "php.ini 之 \"allow_url_fopen\" 值 (最好是 ON)";
$install_lang["allow_url_fopen_ON"]        = "<span style=\"color:#00FF00; font-weight: bold;\">ON</span>";
$install_lang["allow_url_fopen_OFF"]        = "<span style=\"color:#FF0000; font-weight: bold;\">OFF</span>";
$install_lang["succes_upgrade1"]        = "升級完成!";
$install_lang["succes_upgrade2a"]       = "<p>你升級成功 ".$GLOBALS["btit-tracker"]." ".$GLOBALS["current_btit_version"]." 在你的 tracker.</p><p> 升級已被鎖定成功, 防止再被升級一次, 但強烈建議你刪除 <b>upgrade.php+install.php</b> .</p>";
$install_lang["succes_upgrade2b"]       = "<p>你升級成功 ".$GLOBALS["btit-tracker"]." ".$GLOBALS["current_btit_version"]." 在你的 tracker.</p><p> 我們建議您做鎖定安裝. 你可將 <b>install.unlock</b> 改為 <b>install.lock</b> 及刪除 <b>upgrade.php+install.php</b> 這2文件.</p>";
$install_lang["succes_upgrade3"]        = "<p>BTITeam 希望您喜歡使用本產品及參觀我們的 <a href=\"http://www.btiteam.org/smf/index.php\" target=\"_blank\">論壇</a>.</p>";
$install_lang['error_mysql_database']   = '安裝程式無法訪問 &quot;<i>%s</i>&quot; 數據庫.  某些主機, 你必須進入系統控制台創建數據庫.  及些前綴 - 如你的名稱 - 到你的數據庫名稱.';
$install_lang['error_message_click']    = '點擊這裡';
$install_lang['error_message_try_again']= '再試一次';
?>