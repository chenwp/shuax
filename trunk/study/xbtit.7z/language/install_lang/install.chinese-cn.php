<?php
/////////////////////////////////////////////////////////////////////////////////////
// xbtit - Bittorrent tracker/frontend
//
// Copyright (C) 2004 - 2007  Btiteam
//
//    This file is part of xbtit.
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   1. Redistributions of source code must retain the above copyright notice,
//      this list of conditions and the following disclaimer.
//   2. Redistributions in binary form must reproduce the above copyright notice,
//      this list of conditions and the following disclaimer in the documentation
//      and/or other materials provided with the distribution.
//   3. The name of the author may not be used to endorse or promote products
//      derived from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
// WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
// IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
////////////////////////////////////////////////////////////////////////////////////

// english installation file //

$install_lang["charset"]                = "UTF-8";
$install_lang["lang_rtl"]               = FALSE;
$install_lang["step"]                   = "步骤:";
$install_lang["welcome_header"]         = "欢迎";
$install_lang["welcome"]                = "欢迎您安装新的 xbtit ";
$install_lang["installer_language"]     = "语言:";
$install_lang["installer_language_set"] = "启用此语言";
$install_lang["start"]                  = "开始";
$install_lang["next"]                   = "下一步";
$install_lang["back"]                   = "返回";
$install_lang["requirements_check"]     = "检查需求";
$install_lang["reqcheck"]               = "检查需求";
$install_lang["settings"]               = "设置";
$install_lang["system_req"]             = "<p>".$GLOBALS["btit-tracker"]."&nbsp;".$GLOBALS["current_btit_version"]." 需 PHP 4.1.2 或以上版本及 MYSQL 数据库.</p>";
$install_lang["list_chmod"]             = "<p>在进下一步前, 请确认所有文件已上传完毕, 及设置下述文件为可读写 (应设 0777 才行).</p>";
$install_lang["view_log"]               = "你能查看全部的更新日志";
$install_lang["here"]                   = "这里";
$install_lang["settingup"]              = "设置你的tracker";
$install_lang["settingup_info"]         = "基本设置";
$install_lang["sitename"]               = "网站名称";
$install_lang["sitename_input"]         = "xbtit";
$install_lang["siteurl"]                = "网站网址";
$install_lang["siteurl_info"]           = "结尾不要加斜线";
$install_lang["mysql_settings"]         = "MySQL 设置<br />\n建立 MySQL 用户和数据库, 并在这输入信息";
$install_lang["mysql_settings_info"]    = "数据库设置";
$install_lang["mysql_settings_server"]  = "MySQL 伺服 (localhost works ok for most servers)";
$install_lang["mysql_settings_username"] = "MySQL 用户名称";
$install_lang["mysql_settings_password"] = "MySQL 用户密码";
$install_lang["mysql_settings_database"] = "MySQL 数据库名称";
$install_lang["mysql_settings_prefix"]  = "MySQL Table 前缀";
$install_lang["cache_folder"]           = "cache 目录";
$install_lang["torrents_folder"]        = "torrents 目录";
$install_lang["badwords_file"]          = "badwords.txt";
$install_lang["chat.php"]               = "chat.php";
$install_lang["write_succes"]           = "<span style=\"color:#00FF00; font-weight: bold;\">是可写!</span>";
$install_lang["write_fail"]             = "<span style=\"color:#FF0000; font-weight: bold;\">不可写!</span> (0777)";
$install_lang["write_file_not_found"]   = "<span style=\"color:#FF0000; font-weight: bold;\">找不到!</span>";
$install_lang["mysqlcheck"]             = "MySQL 连接检查";
$install_lang["mysqlcheck_step"]        = "MySQL 检查";
$install_lang["mysql_succes"]           = "<span style=\"color:#00FF00; font-weight: bold;\">连接数据库成功!</span>";
$install_lang["mysql_fail"]             = "<span style=\"color:#FF0000; font-weight: bold;\">失败, 无法连接数据库!</span>";
$install_lang["back_to_settings"]       = "返回并填写必要的信息";
$install_lang["saved"]                  = "保存";
$install_lang["file_not_writeable"]     = "这文件 <b>./include/settings.php</b> 不可写.";
$install_lang["file_not_exists"]        = "这文件 <b>./include/settings.php</b> 不存在.";
$install_lang["not_continue_settings"]  = "您不能继续安装,这个文件没有被写入.";
$install_lang["not_continue_settings2"] = "你不能继续此文件.";
$install_lang["settings.php"]           = "./include/settings.php";
$install_lang["can_continue"]           = "您可以继续并稍后再进行此变更";
$install_lang["mysql_import"]           = "MySQL 输入";
$install_lang["mysql_import_step"]      = "SQL 导入";
$install_lang["create_owner_account"]   = "创建站长帐户";
$install_lang["create_owner_account_step"] = "创建站长";
$install_lang["database_saved"]         = "database.sql 已被导入至你的数据库.";
$install_lang["create_owner_account_info"] = "你能在这建立站长帐户";
$install_lang["username"]               = "名称";
$install_lang["password"]               = "密码";
$install_lang["password2"]              = "重覆密码";
$install_lang["email"]                  = "Email";
$install_lang["email2"]                 = "重覆email";
$install_lang["is_succes"]              = "完毕.";
$install_lang["no_leave_blank"]         = "不要留下任何空白.";
$install_lang["not_valid_email"]        = "不确的 email 地址.";
$install_lang["pass_not_same_username"] = "密码不可以和用户名一样.";
$install_lang["email_not_same"]         = "Email 地址错误.";
$install_lang["pass_not_same"]          = "密码错误.";
$install_lang["site_config"]            = "Tracker 设置";
$install_lang["site_config_step"]       = "Tracker 设置";
$install_lang["default_lang"]           = "预设语言";
$install_lang["default_style"]          = "预设风格";
$install_lang["torrents_dir"]           = "Torrents 目录";
$install_lang["validation"]             = "E-mail 验证模式";
$install_lang["more_settings"]          = "*&nbsp;&nbsp;&nbsp;当安装完成后,更多设置在 <u>系统面板</u> .";
$install_lang["tracker_saved"]          = "设置被保存.";
$install_lang["finished"]               = "Rounding up the Installation";
$install_lang["finished_step"]          = "Rounding up";
$install_lang["succes_install1"]        = "安装已完成!";
$install_lang["succes_install2a"]       = "<p>你已成功安装 ".$GLOBALS["btit-tracker"]." ".$GLOBALS["current_btit_version"].".</p><p>, 安装已被锁定成功和 <b>install.php</b> 被删除, 防止再被安装一次.</p>";
$install_lang["succes_install2b"]       = "<p>你已成功安装  ".$GLOBALS["btit-tracker"]." ".$GLOBALS["current_btit_version"].".</p><p>, 我们建议您做锁定安装. 你可将 <b>install.unlock</b> 改为 <b>install.lock</b> 及删除 <b>install.php</b> 文件.</p>";
$install_lang["succes_install3"]        = "<p>BTITeam 希望您喜欢使用本产品及参观我们的 <a href=\"http://www.btiteam.org/smf/index.php\" target=\"_blank\">论坛</a>.</p>";
$install_lang["go_to_tracker"]          = "进入您的 tracker 网站";
$install_lang["forum_type"]             = "论坛型式";
$install_lang["forum_internal"]         = "xbtit 内部论坛";
$install_lang["forum_smf"]              = "smf 论坛";
$install_lang["forum_other"]            = "其它论坛 - 在这输入网址 -->";
$install_lang["smf_download_a"]         = "<strong>如果使用SMF论坛:</strong><br /><br/ >请下载smf论坛最新版本 <a target='_new' href='http://www.simplemachines.org/download/'>这里</a> 且上载好文件并将目录名称改为 \"smf\" 及 <a target='_new' href='smf/install.php'>点这</a> 安装它.*<br /><strong>(请使用相同数据库用于此安装过程).<br /><br /><font color='#FF0000'>第一次安装</font></strong> 请将 SMF English 的语言文件 (<strong>";
$install_lang["smf_download_b"]         = "</strong>) CHMOD to 777 后点击 <strong>下一步</strong> 才能继续安装 xbtit.<br /><br /><strong>* 这两个连结将在另一个新视窗打开,防止你丢失 xbiti 安装.</strong></p>";
$install_lang["smf_err_1"]              = "在 \"smf\" 目录找不到 smf 论坛, 请安装它在继续.<br /><br />点击 <a href=\"javascript: history.go(-1);\">这里</a> 返回到前一页.";
$install_lang["smf_err_2"]              = "数据库内找不到 smf 论坛, 请安装它在继续.<br /><br />点击 <a href=\"javascript: history.go(-1);\">这里</a> 返回到前一页.";
$install_lang["smf_err_3a"]             = "不能写入 SMF 语言文件 (<strong>";
$install_lang["smf_err_3b"]             = "</strong>) 请 CHMOD to 777 在继续.<br /><br />点击 <a href=\"javascript: history.go(-1);\">这里</a> 返回到前一页.";
$install_lang["allow_url_fopen"]        = "php.ini 之 \"allow_url_fopen\" 值 (最好是 ON)";
$install_lang["allow_url_fopen_ON"]        = "<span style=\"color:#00FF00; font-weight: bold;\">ON</span>";
$install_lang["allow_url_fopen_OFF"]        = "<span style=\"color:#FF0000; font-weight: bold;\">OFF</span>";
$install_lang["succes_upgrade1"]        = "升级完成!";
$install_lang["succes_upgrade2a"]       = "<p>你升级成功 ".$GLOBALS["btit-tracker"]." ".$GLOBALS["current_btit_version"]." 在你的 tracker.</p><p> 升级已被锁定成功, 防止再被升级一次, 但强烈建议你删除 <b>upgrade.php+install.php</b> .</p>";
$install_lang["succes_upgrade2b"]       = "<p>你升级成功 ".$GLOBALS["btit-tracker"]." ".$GLOBALS["current_btit_version"]." 在你的 tracker.</p><p> 我们建议您做锁定安装. 你可将 <b>install.unlock</b> 改为 <b>install.lock</b> 及删除 <b>upgrade.php+install.php</b> 这2文件.</p>";
$install_lang["succes_upgrade3"]        = "<p>BTITeam 希望您喜欢使用本产品及参观我们的 <a href=\"http://www.btiteam.org/smf/index.php\" target=\"_blank\">论坛</a>.</p>";
$install_lang['error_mysql_database']   = '安装程式无法访问 &quot;<i>%s</i>&quot; 数据库.  某些主机, 你必须进入系统控制台创建数据库.  及些前缀 - 如你的名称 - 到你的数据库名称.';
$install_lang['error_message_click']    = '点击这里';
$install_lang['error_message_try_again']= '再试一次';
?>