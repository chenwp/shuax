<?php
$language["ACCOUNT_CREATED"]="Nalog uspjesno kreiran";
$language["USER_NAME"]="Korisnik";
$language["USER_PWD_AGAIN"]="Ponovi lozinku";
$language["USER_PWD"]="Lozinka";
$language["USER_STYLE"]="Izgled";
$language["USER_LANGUE"]="Jezik";
$language["IMAGE_CODE"]="Kod na slici";
$language["INSERT_USERNAME"]="Morate unjeti korisnicko ime!";
$language["INSERT_PASSWORD"]="Morate unjeti lozinku!";
$language["DIF_PASSWORDS"]="Lozinke se ne poklapaju!";
$language["ERR_NO_EMAIL"]="Morate unjeti vazecu e-mail adresu!";
$language["USER_EMAIL_AGAIN"]="Ponovite e-mail";
$language["ERR_NO_EMAIL_AGAIN"]="Ponovite e-mail";
$language["DIF_EMAIL"]="E-mailovi se ne poklapaju!";
$language["SECURITY_CODE"]="Odgovorite na pitanje";
# Jacina lozinke
$language["WEEK"]="Slaba";
$language["MEDIUM"]="Srednja";
$language["SAFE"]="Sigurna";
$language["STRONG"]="Jaka #";

?>