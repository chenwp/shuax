<?php

// ENGLISH USERS.PHP FILE

$language["FIND_USER"]       = "Nadji korisnika";
$language["USER_LEVEL"]      = "Rang";
$language["ALL"]             = "Sve";
$language["SEARCH"]          = "Trazi";
$language["USER_NAME"]       = "Korisnik";
$language["USER_JOINED"]     = "Prijava";
$language["USER_LASTACCESS"] = "Zadnja posjeta";
$language["USER_COUNTRY"]    = "Zemlja";
$language["RATIO"]           = "Ratio";
$language["USERS_PM"]        = "PM";
$language["EDIT"]            = "Izmjeni";
$language["DELETE"]          = "Izbrisi";
$language["NO_USERS_FOUND"]  = "Nema korisnika!";
$language["UNKNOWN"]         = "Nepoznat";

?>