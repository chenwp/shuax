<?php
$language["INSERT_USERNAME"]="Korisnicko ime je obavezno!";
$language["INSERT_PASSWORD"]="Lozinka je obavezna!";
?>