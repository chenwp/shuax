<?php
$language["ERR_NO_EMAIL"]="Morate unjeti e-mail adresu";
$language["ERR_INV_EMAIL"]="Unesite vazeci e-mail";
$language["ERR_NO_CAPTCHA"]="Unesite tacan kod, kao na slici";
$language["IMAGE_CODE"]="Kod na slici";
$language["SECURITY_CODE"]="Odgovorite na pitanje";
$language["RECOVER_EMAIL_1"]="\nZatrazili ste reset Lozinke,\nReset zatrazen je asociran sa (%s) e-mail adresom.\n\nLozina i e-mail adresa je registrovana sa %s.\n\nNeznate sta ova poruka treba da znaci? Nepoznata vam je Web adresa? U tom slucaju molimo nemojte odgovarati.\n\n\nUkoliko zelite da nastavite, i resetujete Lozinku, kliknite link ispod:\n\n%s\n\n\nNakon sto kliknete i resetujete vasu Lozinku, dobiti ce te e-mail sa novom Lozinkom.\n--\n%s";
$language["RECOVER_EMAIL_2"]="\nNa vas zahtjev generisali smo novu Lozinku za vas nalog.\n\nOvo je informacija koju trenutno imamo sacuvanu za vas nalog:\n\n    Korisnik: %s\n    Lozinka: %s\n\nPrijaviti se mozete na %s\n\n--\n%s";
?>