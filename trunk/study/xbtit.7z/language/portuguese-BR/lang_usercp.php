<?php
$language["DELETE_READED"]="Apagar";
$language["USER_LANGUE"]="Idioma";
$language["USER_STYLE"]="Estilo";
$language["CURRENTLY_PEER"]="Você atualmente está semeando ou baixando alguns torrents.";
$language["STOP_PEER"]="Você deve parar o seu cliente.";
$language["USER_PWD_AGAIN"]="Repetir a senha";
$language["EMAIL_FAILED"]="O Envio do e-mail falhou!";
$language["NO_SUBJECT"]="Sem assunto";
$language["MUST_ENTER_PASSWORD"]="<br /><font color='#FF0000'><strong>É necessário digitar sua senha para alterar as configurações acima.</strong></font>";
$language["ERR_PASS_WRONG"]="Senha incorreta ou vazia, não pode atualizar perfil.";
$language["MSG_DEL_ALL_PM"]="Se você selecionar PMs, que não foram lidos, elas não serão apagada";
$language["ERR_PM_GUEST"]="Infelizmente você não pode enviar PM ao guest ou para si mesmo!";
?>
