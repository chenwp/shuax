<?php

// ARQUIVO EM PORTUGUÊS USERS.PHP 

$language["FIND_USER"]       = "Localizar Usuário";
$language["USER_LEVEL"]      = "Rank do Usuário";
$language["ALL"]             = "Todos";
$language["SEARCH"]          = "Procurar";
$language["USER_NAME"]       = "Nome de Usuário";
$language["USER_LEVEL"]      = "Rank do Usuário";
$language["USER_JOINED"]     = "Registrado em";
$language["USER_LASTACCESS"] = "Último acesso";
$language["USER_COUNTRY"]    = "País";
$language["RATIO"]           = "Média";
$language["USERS_PM"]        = "PM";
$language["EDIT"]            = "Editar";
$language["DELETE"]          = "Apagar";
$language["NO_USERS_FOUND"]  = "Nenhum usuário encontrado!";
$language["UNKNOWN"]         = "Desconhecido";

?>
