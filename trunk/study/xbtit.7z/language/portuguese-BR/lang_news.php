<?php
$language["ERR_NO_TITLE"]="Você deve fornecer um título para sua notícia";
?>
