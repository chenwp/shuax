<?php
$language["BLOCK_USER"]="Information utilisateur";
$language["BLOCK_INFO"]="Information tracker";
$language["BLOCK_MENU"]="Menu";
$language["BLOCK_CLOCK"]="Horloge";
$language["BLOCK_FORUM"]="Forum";
$language["BLOCK_LASTMEMBER"]="Dernier membre";
$language["BLOCK_ONLINE"]="En ligne";
$language["BLOCK_ONTODAY"]="Aujourd'hui";
$language["BLOCK_SHOUTBOX"]="Shout Box";
$language["BLOCK_TOPTORRENTS"]="Top Torrents";
$language["BLOCK_LASTTORRENTS"]="Dernier Upload";
$language["BLOCK_NEWS"]="Derni�res News";
$language["BLOCK_SERVERLOAD"]="Charge du serveur";
$language["BLOCK_POLL"]="Sondage";
$language["BLOCK_SEEDWANTED"]="Besoin de seeders";
$language["BLOCK_PAYPAL"]="Support US";
$language["BLOCK_MAINTRACKERTOOLBAR"]="Main Tracker Toolbar";
$language["BLOCK_MAINUSERTOOLBAR"]="Barre d'outils";
$language["WELCOME_LASTUSER"]=" Bienvenue sur notre tracker ";
$language["BLOCK_MINCLASSVIEW"]="Rang minimum qui peut etre vu";
$language["BLOCK_MAXCLASSVIEW"]="Rang maximum qui peut etre vu";
?>