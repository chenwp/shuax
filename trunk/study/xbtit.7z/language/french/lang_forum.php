<?php
$language["SUBFORUM"]="Sous-forum";
$language["SUBFORUMS"]="<b>Sous-forum</b>";
$language["NEW_TOPIC"]="Nouveau sujet";
$language["NO_TOPICS"]="Desol�, il n'y a aucun sujet.";
$language["LOCKED"]="Sujet bloqu�";
$language["LOCKED_NEW"]="Sujet bloqu� (Nouveau)";
$language["UNLOCKED"]="Pas de nouvelles reponses";
$language["UNLOCKED_NEW"]="Nouvelles reponses";
$language["ERR_CANT_START_TOPICS"]="Vous n'�tes pas autoris� � cr�er un nouveau sujet sur ce forum.";
$language["BAD_FORUM_ID"]="Mauvais identifiant de forum";
$language["MOD_OPTION"]="Options de moderation";
$language["SET_STICKY"]="Activer/Desactiver post-it";
$language["SET_LOCKED"]="Bloquer/Debloquer sujet";
$language["RENAME_TOPIC"]="Renommer le sujet";
$language["DELETE_TOPIC"]="Supprimer le sujet";
$language["MOVE_TOPIC"]="D�placer ce sujet vers";
$language["MOVE"]="D�placer";
$language["ADD_REPLY"]="Ajouter reponse";
$language["BAD_TOPIC_ID"]="Mauvais identifiant de sujet";
$language["LAST_10_POSTS"]="10 derniers posts, en ordre invers�";
$language["LAST_EDITED_BY"]="Derni�re �dition par";
$language["ERR_POST_ID_NA"]="L'identifiant du poste n'a pas �t� fourni";
$language["ERR_FORUM_TOPIC"]="Mauvais identifiant de forum ou de sujet.";
$language["ERR_POST_NOT_FOUND"]="Le post n'a pas �t� trouv�";
$language["ERR_POST_UNIQUE"]="Impossible de supprimer le post ; c'est le premier post de ce sujet. Vous devez";
$language["ERR_POST_UNIQUE_2"]="supprimer le sujet";
$language["ERR_POST_UNIQUE_3"]=""; //"instead"
$language["TOPIC_LOCKED"]="Le sujet est bloqu� ; vous ne pouvez pas y repondre.";
$language["TOPIC_NOT_FOUND"]="Le sujet n'a pas �t� trouv�";
$language["TOPIC_UNREAD_POSTS"]="Sujets comportant des posts non lus";
$language["POST"]="Post";
$language["SEARCH_AGAIN"]="Continuer la recherche";
$language["SEARCH_HELP"]="Saisissez un mot ou plus � rechercher.<br />Les mots de moins de 3 lettres sont ignor�s.";
$language["SEARCHED_FOR"]="Recherch�";

?>