<?php
$language["ACCOUNT_CREATED"]="Compte cr�e";
$language["USER_NAME"]="Utilisateur";
$language["USER_PWD_AGAIN"]="Confirmez le mot de passe";
$language["USER_PWD"]="Mot de passe";
$language["USER_STYLE"]="Style";
$language["USER_LANGUE"]="Langage";
$language["IMAGE_CODE"]="Code image";
$language["INSERT_USERNAME"]="Vous devez saisir un nom d'utilisateur !";
$language["INSERT_PASSWORD"]="Vous devez saisir un mot de passe !";
$language["DIF_PASSWORDS"]="Les mot de passe ne correspondent pas !";
$language["ERR_NO_EMAIL"]="Vous devez saisir un email valide !";
$language["USER_EMAIL_AGAIN"]="Confirmez l'email";
$language["ERR_NO_EMAIL_AGAIN"]="Confirmez l'email";
$language["DIF_EMAIL"]="Les emails ne correspondent pas !";
$language["SECURITY_CODE"]="Repondez � la question";
# Password strength
$language["WEEK"]="Faible";
$language["MEDIUM"]="Moyen";
$language["SAFE"]="Securis�";
$language["STRONG"]="Fort";

?>