<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language['POSTED_BY']   = 'Posted by';
$language['POSTED_DATE'] = 'Date posted';
$language['TITLE']       = 'Title';
$language['ADD']         = 'Add';

?>
