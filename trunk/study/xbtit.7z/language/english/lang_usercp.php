<?php
$language['DELETE_READED']='Delete';
$language['USER_LANGUE']='Language';
$language['USER_STYLE']='Style';
$language['CURRENTLY_PEER']='You&rsquo;re currently seeding or leeching some torrent.';
$language['STOP_PEER']='You must stop your client.';
$language['USER_PWD_AGAIN']='Repeat password';
$language['EMAIL_FAILED']='Sending email has failed!';
$language['NO_SUBJECT']='No subject';
$language['MUST_ENTER_PASSWORD']='<br /><font color="#FF0000"><strong>You must enter your password to change the settings above.</strong></font>';
$language['ERR_PASS_WRONG']='Password empty or incorrect, cannot update profile.';
$language['MSG_DEL_ALL_PM']='If you select PMs which are not read, they will not be deleted';
$language['ERR_PM_GUEST']='Sorry you can&rsquo;t send PM to guest or to yourself!';
?>