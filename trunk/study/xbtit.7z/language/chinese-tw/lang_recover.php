<?php
$language['ERR_NO_EMAIL']='你必須提供一個email地址';
$language['ERR_INV_EMAIL']='你必須輸入一個有效的email地址';
$language['ERR_NO_CAPTCHA']='你必須輸入驗證碼';
$language['IMAGE_CODE']='驗證碼';
$language['SECURITY_CODE']='回答該問題';
$language['RECOVER_EMAIL_1']="\n".'某人, 希望您, 請求被重置與此email地址 (%s) 相關聯的帳戶的密碼'."\n\n".'該請求來自 %s.'."\n\n".'如果您不是,就忽略此封email,請不要回信'."\n\n".'你要確認此請求，請按此連結：'."\n\n".'%s'."\n\n".'執行此操作後，將重置您的密碼，並回信給你。'."\n--\n".'%s';
$language['RECOVER_EMAIL_2']="\n".'按您的請求,我們有生成您的帳戶新密碼,'."\n\n".'以下是該帳戶的相關內容:'."\n\n\t".'名稱: %s'."\n\n\t".'密碼: %s'."\n\n".'你可以登錄在 %s'."\n\n--\n".'%s';
?>