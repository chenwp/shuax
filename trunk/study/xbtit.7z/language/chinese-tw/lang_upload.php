<?php
$language['NOT_SHA']='SHA1變量不可用. 請使用PHP 4.3.0或更新的版本.';
$language['NOT_AUTHORIZED_UPLOAD']='您無權上傳!';
$language['FACOLTATIVE']='可選的';
$language['ERR_PARSER']='你的種子似乎有錯誤. 系統無法接受.';
$language['WRITE_CATEGORY']='必須指定種子的所屬分類...';
$language['DOWNLOAD']='下載';
$language['MSG_UP_SUCCESS']='上傳成功! 種子已經加入系統.';
$language['MSG_DOWNLOAD_PID']='PID系統已獲取了您的種子的PID';
$language['EMPTY_DESCRIPTION']='你必須輸入描述!';
$language['EMPTY_ANNOUNCE']='發表是空的';
$language['FILE_UPLOAD_ERROR_1']='無法讀取已上傳的文件';
$language['FILE_UPLOAD_ERROR_2']='文件上傳錯誤';
$language['FILE_UPLOAD_ERROR_3']='文件大小為0';
$language['NO_SHA_NO_UP']='無法上傳文件 - SHA1變量不可用.';
$language['ERR_HASH']='文件的hash值,必須是個40位的16進制字節.';
$language['ERR_EXTERNAL_NOT_ALLOWED']='不充許外部種子';
$language['ERR_MOVING_TORR']='移動種子出錯...';
$language['ERR_ALREADY_EXIST']='我們的數據庫中,可能已存在該種子.';
$language['MSG_DOWNLOAD_PID']='PID系統已獲取了您種子的PID';
$language['MSG_UP_SUCCESS']='上傳成功! 種子已經加入系統.';
?>