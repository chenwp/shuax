<?php

// USERDETAILS.PHP LANGUAGE FILE

$language['USERNAME']           = '名稱';
$language['EMAIL']              = 'Email';
$language['LAST_IP']            = '最後登錄IP';
$language['USER_LEVEL']         = '等別';
$language['USER_JOINED']        = '註冊於';
$language['USER_LASTACCESS']    = '上次訪問';
$language['PEER_COUNTRY']       = '國家';
$language['USER_LOCAL_TIME']    = '用戶時區';
$language['DOWNLOADED']         = '已下載';
$language['UPLOADED']           = '已上傳';
$language['RATIO']              = '分享率';
$language['FORUM']              = '論壇';
$language['POSTS']              = '貼子';
$language['POSTS_PER_DAY']      = '每日 %s 貼子';
$language['TORRENTS']           = '種子';
$language['FILE']               = '文件';
$language['ADDED']              = '時間';
$language['SIZE']               = '大小';
$language['SHORT_S']            = '做種';
$language['SHORT_L']            = '吸血';
$language['SHORT_C']            = '完成';
$language['NO_TORR_UP_USER']    = '該用戶沒有上傳過種子!';
$language['ACTIVE_TORRENT']     = '活躍種子';
$language['PEER_STATUS']        = '狀態';
$language['NO_ACTIVE_TORR']     = '無活躍種子';
$language['PEER_CLIENT']        = '客戶端';
$language['EDIT']               = '編輯';
$language['DELETE']             = '刪除';
$language['PM']                 = '短消息';
$language['BACK']               = '返回';
$language['NO_HISTORY']         = '無記錄可顯示...';
?>