<?php
$language['ACCOUNT_CREATED']='帳戶已創建';
$language['USER_NAME']='用戶';
$language['USER_PWD_AGAIN']='重覆密碼';
$language['USER_PWD']='密碼';
$language['USER_STYLE']='風格';
$language['USER_LANGUE']='語言';
$language['IMAGE_CODE']='驗證碼';
$language['INSERT_USERNAME']='你必須輸入用戶名!';
$language['INSERT_PASSWORD']='你必須輸入密碼!';
$language['DIF_PASSWORDS']='該密碼不能匹配!';
$language['ERR_NO_EMAIL']='你必須輸入一個有效的 email 位址';
$language['USER_EMAIL_AGAIN']='重覆 email';
$language['ERR_NO_EMAIL_AGAIN']='重覆 email';
$language['DIF_EMAIL']='該 emails 不能匹配!';
$language['SECURITY_CODE']='回答該問題';
# Password strength
$language['WEEK']='弱';
$language['MEDIUM']='中';
$language['SAFE']='安全';
$language['STRONG']='強';
?>