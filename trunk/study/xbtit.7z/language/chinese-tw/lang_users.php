<?php

// ENGLISH USERS.PHP FILE

$language['FIND_USER']       = '查找用戶';
$language['USER_LEVEL']      = '級別';
$language['ALL']             = '全部';
$language['SEARCH']          = '搜索';
$language['USER_NAME']       = '名稱';
$language['USER_LEVEL']      = '級別';
$language['USER_JOINED']     = '註冊於';
$language['USER_LASTACCESS'] = '上次訪問';
$language['USER_COUNTRY']    = '國家';
$language['RATIO']           = '分享率';
$language['USERS_PM']        = '短消息';
$language['EDIT']            = '編輯';
$language['DELETE']          = '刪除';
$language['NO_USERS_FOUND']  = '目前沒有找到用戶!';
$language['UNKNOWN']         = '未知';

?>