<?php
$language['PEER_PROGRESS']='進度';
$language['PEER_COUNTRY']='國家';
$language['PEER_PORT']='端口';
$language['PEER_STATUS']='狀態';
$language['PEER_CLIENT']='客戶端';
$language['NO_PEERS']='沒有用戶';
?>