<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language['POSTED_BY']   = '發佈人';
$language['POSTED_DATE'] = '時間';
$language['TITLE']       = '標題';
$language['ADD']         = '添加';

?>
