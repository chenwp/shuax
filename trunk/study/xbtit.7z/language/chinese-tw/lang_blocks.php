<?php
$language['BLOCK_USER']='用戶訊息';
$language['BLOCK_INFO']='Tracker 信息';
$language['BLOCK_MENU']='主菜單';
$language['BLOCK_CLOCK']='時鐘';
$language['BLOCK_FORUM']='論壇';
$language['BLOCK_LASTMEMBER']='最新會員';
$language['BLOCK_ONLINE']='線上';
$language['BLOCK_ONTODAY']='今天';
$language['BLOCK_SHOUTBOX']='交流廳';
$language['BLOCK_TOPTORRENTS']='熱門種子';
$language['BLOCK_LASTTORRENTS']='最新上傳';
$language['BLOCK_NEWS']='新聞';
$language['BLOCK_SERVERLOAD']='伺服負載';
$language['BLOCK_POLL']='投票';
$language['BLOCK_SEEDWANTED']='Seed Wanted Torrents';
$language['BLOCK_PAYPAL']='贊助';
$language['BLOCK_MAINTRACKERTOOLBAR']='Tracker工具欄';
$language['BLOCK_MAINUSERTOOLBAR']='用戶工具欄';
$language['WELCOME_LASTUSER']=' 歡迎參觀我的站台 ';
$language['BLOCK_MINCLASSVIEW']='最低權限能瀏覽';
$language['BLOCK_MAXCLASSVIEW']='最高權限能瀏覽';
?>