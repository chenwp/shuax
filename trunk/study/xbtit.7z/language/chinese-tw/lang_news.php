<?php
$language['ERR_NO_TITLE']='你必須為你的新聞提供一個標題';
?>