<?php
$language['INSERT_USERNAME']='你必須輸入名稱!';
$language['INSERT_PASSWORD']='你必須輸入密碼!';
?>