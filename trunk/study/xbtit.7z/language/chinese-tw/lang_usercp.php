<?php
$language['DELETE_READED']='刪除';
$language['USER_LANGUE']='語言';
$language['USER_STYLE']='風格';
$language['CURRENTLY_PEER']='你目前做種或吸血的種子';
$language['STOP_PEER']='你必須停止你的客戶端';
$language['USER_PWD_AGAIN']='重複密碼';
$language['EMAIL_FAILED']='發送email已失敗!';
$language['NO_SUBJECT']='無主題';
$language['MUST_ENTER_PASSWORD']='<br /><font color="#FF0000"><strong>您必須輸入密碼,才可修改上述設置.</strong></font>';
$language['ERR_PASS_WRONG']='未輸入密碼或輸入密碼錯誤,您不能修改您的資料.';
$language['MSG_DEL_ALL_PM']='如果您選取未讀的短消息,他們不會被刪除';
$language['ERR_PM_GUEST']='抱歉,你不能發送短消息給訪客或自已!';
?>