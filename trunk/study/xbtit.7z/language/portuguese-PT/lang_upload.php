<?php
$language["NOT_SHA"]="Função SHA1 indisponível. Precisas do PHP 4.3.0 ou superior.";
$language["NOT_AUTHORIZED_UPLOAD"]="Não estás autorizado a fazer upload.";
$language["FILE_UPLOAD_ERROR_1"]="Impossível ler o arquivo enviado.";
$language["FILE_UPLOAD_ERROR_3"]="O arquivo tem zero de tamanho.";
$language["FACOLTATIVE"]="Opcional";
$language["FILE_UPLOAD_ERROR_2"]="Erro ao enviar arquivo";
$language["ERR_PARSER"]="Parece haver um erro na tua torrent. O parser rejeitou-a.";
$language["WRITE_CATEGORY"]="Deves especificar a categoria da torrent.";
$language["DOWNLOAD"]="Download";
$language["MSG_UP_SUCCESS"]="Enviado com sucesso! A torrent foi adicionada.";
$language["MSG_DOWNLOAD_PID"]="Sistema PID activo, descarrega a tua torrent com o teu PID";
$language["EMPTY_DESCRIPTION"]="Deves digitar uma descrição.";
$language["EMPTY_ANNOUNCE"]="O announce está vazio";
$language["FILE_UPLOAD_ERROR_1"]="Impossível ler o arquivo carregado";
$language["FILE_UPLOAD_ERROR_2"]="Erro ao enviar arquivo.";
$language["FILE_UPLOAD_ERROR_3"]="O arquivo tem zero de tamanho";
$language["NO_SHA_NO_UP"]="Arquivo enviado não disponível - Nenhuma função SHA1.";
$language["NOT_SHA"]="Função SHA1 não disponível. Necessitas do PHP 4.3.0 ou superior.";
$language["ERR_PARSER"]="Parece haver um erro na tua torrent. O parser rejeitou-a.";
$language["WRITE_CATEGORY"]="Deves especificar a categoria da torrent.";
$language["ERR_HASH"]="A Infohash deve conter exactamente 40 hex bytes.";
$language["ERR_EXTERNAL_NOT_ALLOWED"]="Torrents externas não são permitidas";
$language["ERR_MOVING_TORR"]="Erro ao mover torrent.";
$language["ERR_ALREADY_EXIST"]="Esta torrent pode já existir na nossa base de dados.";
$language["MSG_DOWNLOAD_PID"]="Sistema PID activo, descarrega a torrent com o teu PID";
$language["MSG_UP_SUCCESS"]="Enviado com sucesso! A torrent foi adicionada.";
?>
