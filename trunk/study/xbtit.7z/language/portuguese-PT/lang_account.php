<?php
$language["ACCOUNT_CREATED"]="Conta Criada";
$language["USER_NAME"]="Utilizador";
$language["USER_PWD_AGAIN"]="Repete a senha";
$language["USER_PWD"]="Senha";
$language["USER_STYLE"]="Estilo";
$language["USER_LANGUE"]="Idioma";
$language["IMAGE_CODE"]="Código da imagem";
$language["INSERT_USERNAME"]="Deves inserir um nome de utilizador.";
$language["INSERT_PASSWORD"]="Deves inserir uma senha.";
$language["DIF_PASSWORDS"]="As senhas não coincidem.";
$language["ERR_NO_EMAIL"]="É preciso digitar um endereço de e-mail válido";
$language["USER_EMAIL_AGAIN"]="Repete o e-mail";
$language["ERR_NO_EMAIL_AGAIN"]="Repete o e-mail";
$language["DIF_EMAIL"]="Os e-mails não coincidem.";
$language["SECURITY_CODE"]="Responde à pergunta";
# Password strength
$language["WEEK"]="Fraco";
$language["MEDIUM"]="Média";
$language["SAFE"]="Segura";
$language["STRONG"]="Forte";

?>
