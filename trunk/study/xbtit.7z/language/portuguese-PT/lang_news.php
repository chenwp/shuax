<?php
$language["ERR_NO_TITLE"]="Deves fornecer um título para a notícia";
?>
