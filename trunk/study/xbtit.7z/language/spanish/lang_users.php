<?php

// ENGLISH USERS.PHP FILE

$language['FIND_USER']       = 'Encontrar usuario';
$language['USER_LEVEL']      = 'Rango';
$language['ALL']             = 'Todo';
$language['SEARCH']          = 'Buscar';
$language['USER_NAME']       = 'Usuario';
$language['USER_LEVEL']      = 'Rango';
$language['USER_JOINED']     = 'Registrado el';
$language['USER_LASTACCESS'] = '�ltimo acceso';
$language['USER_COUNTRY']    = 'Pa�s';
$language['RATIO']           = 'Ratio';
$language['USERS_PM']        = 'MP';
$language['EDIT']            = 'Editar';
$language['DELETE']          = 'Borrar';
$language['NO_USERS_FOUND']  = '�Usuarios no encontrados!';
$language['UNKNOWN']         = 'Desconocido';

?>