<?php

// ENGLISH USERS.PHP FILE

$language["FIND_USER"]       = "Найти Пользователя";
$language["USER_LEVEL"]      = "Ранк Пользователь";
$language["ALL"]             = "Все";
$language["SEARCH"]          = "Искать";
$language["USER_NAME"]       = "Имя Пользователя";
$language["USER_LEVEL"]      = "Ранк Пользователя";
$language["USER_JOINED"]     = "Зарегистрировался";
$language["USER_LASTACCESS"] = "Последний Вход";
$language["USER_COUNTRY"]    = "Страна";
$language["RATIO"]           = "Рейтинг";
$language["USERS_PM"]        = "ЛС";
$language["EDIT"]            = "Редактировать";
$language["DELETE"]          = "Удалить";
$language["NO_USERS_FOUND"]  = "Пользователи не найдены!";
$language["UNKNOWN"]         = "Неизвестно";

?>