<?php
// Traduzione eseguita da mOOn, con il QCheck di Laurianti.
//Un grazie anche a Confe, e a chi si è prodigato nel testare il Tracker
// Per qualsiasi info ci trovate su http://www.btiteam.org
$language["TORRENT_SEARCH"]="Ricerca Torrent";
$language["TORRENT_STATUS"]="Stato";
$language["CATEGORY_FULL"]="Categoria";
$language["ALL"]="Tutti";
$language["ACTIVE_ONLY"]="Solo Attivi";
$language["DEAD_ONLY"]="Solo Inattivi";
$language["SEARCH"]="Ricerca";
$language["CATEGORY"]="Cat.";
$language["FILE"]="Nome";
$language["COMMENT"]="Comm.";
$language["RATING"]="Voto";
$language["DOWN"]="Dl";
$language["ADDED"]="Data";
$language["SIZE"]="Dimensione";
$language["UPLOADER"]="Uploader";
$language["SHORT_S"]="D";
$language["SHORT_L"]="R";
$language["SHORT_C"]="C";
$language["DOWNLOADED"]="Down";
$language["SPEED"]="Velocità";
$language["AVERAGE"]="Av.";
$language["VOTE"]="Voto!";
$language["VOTES_RATING"]="voti (valutazione";
$language["FIVE_STAR"]="5 stelle";
$language["FOUR_STAR"]="4 stelle";
$language["ONE_STAR"]="1 stella";
$language["THREE_STAR"]="3 stelle";
$language["TWO_STAR"]="2 stelle";
$language["YOU_RATE"]="hai valutato questo torrent";
$language["ADD_RATING"]="aggiungi valutazione";
$language["RATING"]="Voto";
$language["ERR_NO_VOTE"]="Devi scegliere un valore per votare.";
$language["VOTES"]="Voti";
$language["SHOW_HIDE"]="Mostra/Nascondi file";
?>