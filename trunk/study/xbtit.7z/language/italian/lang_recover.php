<?php
// Traduzione eseguita da mOOn, con il QCheck di Laurianti.
//Un grazie anche a Confe, e a chi si è prodigato nel testare il Tracker
// Per qualsiasi info ci trovate su http://www.btiteam.org
$language["ERR_NO_EMAIL"]="Devi fornire un indirizzo email";
$language["ERR_INV_EMAIL"]="Devi inserire un indirizzo di email valido";
$language["ERR_NO_CAPTCHA"]="Devi inserire il codice in immagine'ImageCode'";
$language["IMAGE_CODE"]="Codice Immagine";
$language["SECURITY_CODE"]="Rispondi alla domanda";
?>