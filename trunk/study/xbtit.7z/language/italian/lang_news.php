<?php
// Traduzione eseguita da mOOn, con il QCheck di Laurianti.
//Un grazie anche a Confe, e a chi si è prodigato nel testare il Tracker
// Per qualsiasi info ci trovate su http://www.btiteam.org
$language["ERR_NO_TITLE"]="Devi offrire un titolo per le tue news!";
?>