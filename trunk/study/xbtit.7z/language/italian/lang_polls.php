<?php
// Traduzione eseguita da mOOn, con il QCheck di Laurianti.
//Un grazie anche a Confe, e a chi si è prodigato nel testare il Tracker
// Per qualsiasi info ci trovate su http://www.btiteam.org
$language["POLL_ID"]="ID";
$language["LATEST_POLL"]="Ultimo sondaggio";
$language["CAST_VOTE"]="Assegna il mio voto";
$language["FETCHING_RESULTS"]="Risultati dei sondaggi che si ottengono.Attendere prego...";
$language["POLL_TITLE"]="Titolo Sondaggio";
$language["POLL_TITLE_MISSING"]="Titolo sondaggio mancante";
$language["POLLING_SYSTEM"]="Sistema AJAX di Sondaggi";
$language["CURRENT_POLLS"]="Sondaggio Corrente";
$language["POLL_STARTED"]="Partito il";
$language["POLL_ENDED"]="Finito il";
$language["POLL_LASTED"]="L'ultimo";
$language["POLL_BY"]="Partito da";
$language["POLL_VOTES"]="Voti";
$language["POLL_STILL_ACTIVE"]="Ancora attivo";
$language["POLL_NEW"]="Nuovo";
$language["POLL_START_NEW"]="Avvia un nuovo sondaggio";
$language["POLL_ACTIVE"]="Attivo";
$language["POLL_ACTIVE_TRUE"]="Attivo";
$language["POLL_ACTIVE_FALSE"]="Inattivo";
$language["POLL_OPTION"]="Opzione";
$language["POLL_OPTIONS"]="Opzioni";
$language["POLL_MOVE"]="Muovi giù";
$language["POLL_NEW_OPTIONS"]="Nuove opzioni";
$language["POLL_SAVE"]="Salva";
$language["POLL_CANCEL"]="Cancella";
$language["POLL_DELETE"]="Elimina";
$language["POLL_DEL_CONFIRM"]="Clicca OK per eliminare questo sondaggio";
$language["POLL_VOTERS"]="Voti Sondaggio";
$language["POLL_IP_ADDRESS"]="Indirizzo IP";
$language["POLL_DATE"]="Data";
$language["POLL_USER"]="Utente";
$language["POLL_ACCOUNT_DEL"]="<i>account eliminato</i>";
$language["POLL_BACK"]="Indietro";
$language["YEAR"]="anno";
$language["MONTH"]="mese";
$language["WEEK"]="settimana";
$language["DAY"]="giorno";
$language["HOUR"]="ora";
$language["MINUTE"]="minuti";
$language["SECOND"]="secondi";
$language["YEARS"]="anni";
$language["MONTHS"]="mesi";
$language["WEEKS"]="settimane";
$language["DAYS"]="giorni";
$language["HOURS"]="ore";
$language["MINUTES"]="minuti";
$language["SECONDS"]="secondi";
?>