<?php
$language["ERR_NO_TITLE"]="Du musst dieser News einen Titel geben";
?>