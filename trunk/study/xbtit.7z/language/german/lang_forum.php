<?php
$language["SUBFORUM"]="SubForum";
$language["SUBFORUMS"]="<b>SubForums</b>";
$language["NEW_TOPIC"]="Neues Thema";
$language["NO_TOPICS"]="Sorry, kein Thema vorhanden.";
$language["LOCKED"]="Gesperrtes Thema";
$language["LOCKED_NEW"]="Gesperrtes Thema (Neu)";
$language["UNLOCKED"]="Keine neuen Antworten";
$language["UNLOCKED_NEW"]="Neue Antworten";
$language["ERR_CANT_START_TOPICS"]="Du darfst in diesem Forum kein neues Thema er�ffnen";
$language["BAD_FORUM_ID"]="Ung�ltige Forum ID";
$language["MOD_OPTION"]="Moderations Optionen";
$language["SET_STICKY"]="Setzen/L�sen Sticky";
$language["SET_LOCKED"]="Sperren/Entsperren Thema";
$language["RENAME_TOPIC"]="Thema umbenennen";
$language["DELETE_TOPIC"]="Thema l�schen";
$language["MOVE_TOPIC"]="Thema verschieben nach";
$language["MOVE"]="Verschieben";
$language["ADD_REPLY"]="Antwort hinzuf�gen";
$language["BAD_TOPIC_ID"]="Ung�ltige Themen ID";
$language["LAST_10_POSTS"]="10 letzte Beitr�ge, in umgekehrter Reihenfolge";
$language["LAST_EDITED_BY"]="Zuletzt ge�ndert durch";
$language["ERR_POST_ID_NA"]="Post ID ist N/A";
$language["ERR_FORUM_TOPIC"]="Ung�ltige Forum oder Themen ID";
$language["ERR_POST_NOT_FOUND"]="Beitrag nicht gefunden";
$language["ERR_POST_UNIQUE"]="Kann den Beitrag nicht l�schen; es ist der einzige Beitrag in diesem Thema. Du solltest es tun";
$language["ERR_POST_UNIQUE_2"]="Beitrag l�schen";
$language["ERR_POST_UNIQUE_3"]="stattdessen";
$language["TOPIC_LOCKED"]="Dieses Thema ist gesperrt; es sind keine Beitr�ge erlaubt";
$language["TOPIC_NOT_FOUND"]="Thema nicht gefunden";
$language["TOPIC_UNREAD_POSTS"]="Themen mit ungelesenen Beitr�gen";
$language["POST"]="Beitrag";
$language["SEARCH_AGAIN"]="Erneut suchen";
$language["SEARCH_HELP"]="Gib ein oder mehrere W�rter zum suchen ein<br />Einfache W�rter, oder solche mit weniger als 3 Buchstaben werden ignoriert";
$language["SEARCHED_FOR"]="Gesucht nach";

?>