<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language['POSTED_BY']   = '发布人';
$language['POSTED_DATE'] = '时间';
$language['TITLE']       = '标题';
$language['ADD']         = '添加';

?>
