<?php
$language['ERR_NO_EMAIL']='你必须提供一个email地址';
$language['ERR_INV_EMAIL']='你必须输入一个有效的email地址';
$language['ERR_NO_CAPTCHA']='你必须输入验证码';
$language['IMAGE_CODE']='验证码';
$language['SECURITY_CODE']='回答该问题';
$language['RECOVER_EMAIL_1']="\n".'某人, 希望您, 请求被重置与此email地址 (%s) 相关联的帐户的密码'."\n\n".'该请求来自 %s.'."\n\n".'如果您不是,就忽略此封email,请不要回信'."\n\n".'你要确认此请求，请按此连结：'."\n\n".'%s'."\n\n".'执行此操作后，将重置您的密码，并回信给你。'."\n--\n".'%s';
$language['RECOVER_EMAIL_2']="\n".'按您的请求,我们有生成您的帐户新密码,'."\n\n".'以下是该帐户的相关内容:'."\n\n\t".'名称: %s'."\n\n\t".'密码: %s'."\n\n".'你可以登录在 %s'."\n\n--\n".'%s';
?>