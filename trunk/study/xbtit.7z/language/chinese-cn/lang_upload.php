<?php
$language['NOT_SHA']='SHA1变量不可用. 请使用PHP 4.3.0或更新的版本.';
$language['NOT_AUTHORIZED_UPLOAD']='您无权上传!';
$language['FACOLTATIVE']='可选的';
$language['ERR_PARSER']='你的种子似乎有错误. 系统无法接受.';
$language['WRITE_CATEGORY']='必须指定种子的所属分类...';
$language['DOWNLOAD']='下载';
$language['MSG_UP_SUCCESS']='上传成功! 种子已经加入系统.';
$language['MSG_DOWNLOAD_PID']='PID系统已获取了您的种子的PID';
$language['EMPTY_DESCRIPTION']='你必须输入描述!';
$language['EMPTY_ANNOUNCE']='发表是空的';
$language['FILE_UPLOAD_ERROR_1']='无法读取已上传的文件';
$language['FILE_UPLOAD_ERROR_2']='文件上传错误';
$language['FILE_UPLOAD_ERROR_3']='文件大小为0';
$language['NO_SHA_NO_UP']='无法上传文件 - SHA1变量不可用.';
$language['ERR_HASH']='文件的hash值,必须是个40位的16进制字节.';
$language['ERR_EXTERNAL_NOT_ALLOWED']='不充许外部种子';
$language['ERR_MOVING_TORR']='移动种子出错...';
$language['ERR_ALREADY_EXIST']='我们的数据库中,可能已存在该种子.';
$language['MSG_DOWNLOAD_PID']='PID系统已获取了您种子的PID';
$language['MSG_UP_SUCCESS']='上传成功! 种子已经加入系统.';
$language['NO']='否';
$language['YES']='是';
?>