<?php

// USERDETAILS.PHP LANGUAGE FILE

$language['USERNAME']           = '名称';
$language['EMAIL']              = 'Email';
$language['LAST_IP']            = '最后登录IP';
$language['USER_LEVEL']         = '等别';
$language['USER_JOINED']        = '注册于';
$language['USER_LASTACCESS']    = '上次访问';
$language['PEER_COUNTRY']       = '国家';
$language['USER_LOCAL_TIME']    = '用户时区';
$language['DOWNLOADED']         = '已下载';
$language['UPLOADED']           = '已上传';
$language['RATIO']              = '分享率';
$language['FORUM']              = '论坛';
$language['POSTS']              = '贴子';
$language['POSTS_PER_DAY']      = '每日 %s 贴子';
$language['TORRENTS']           = '种子';
$language['FILE']               = '文件';
$language['ADDED']              = '时间';
$language['SIZE']               = '大小';
$language['SHORT_S']            = '做种';
$language['SHORT_L']            = '下载';
$language['SHORT_C']            = '完成';
$language['NO_TORR_UP_USER']    = '该用户没有上传过种子!';
$language['ACTIVE_TORRENT']     = '活跃种子';
$language['PEER_STATUS']        = '状态';
$language['NO_ACTIVE_TORR']     = '无活跃种子';
$language['PEER_CLIENT']        = '客户端';
$language['EDIT']               = '编辑';
$language['DELETE']             = '删除';
$language['PM']                 = '短消息';
$language['BACK']               = '返回';
$language['NO_HISTORY']         = '无记录可显示...';
?>