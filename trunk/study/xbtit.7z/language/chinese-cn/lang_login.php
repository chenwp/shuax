<?php
$language['INSERT_USERNAME']='你必须输入名称!';
$language['INSERT_PASSWORD']='你必须输入密码!';
?>