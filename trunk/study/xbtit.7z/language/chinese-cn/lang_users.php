<?php

// ENGLISH USERS.PHP FILE

$language['FIND_USER']       = '查找用户';
$language['USER_LEVEL']      = '级别';
$language['ALL']             = '全部';
$language['SEARCH']          = '搜索';
$language['USER_NAME']       = '名称';
$language['USER_LEVEL']      = '级别';
$language['USER_JOINED']     = '注册于';
$language['USER_LASTACCESS'] = '上次访问';
$language['USER_COUNTRY']    = '国家';
$language['RATIO']           = '分享率';
$language['USERS_PM']        = '短消息';
$language['EDIT']            = '编辑';
$language['DELETE']          = '删除';
$language['NO_USERS_FOUND']  = '目前没有找到用户!';
$language['UNKNOWN']         = '未知';

?>