<?php
$language['ERR_NO_TITLE']='你必须为你的新闻提供一个标题';
?>