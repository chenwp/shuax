<?php
$language['ACCOUNT_CREATED']='帐户已创建';
$language['USER_NAME']='用户';
$language['USER_PWD_AGAIN']='重覆密码';
$language['USER_PWD']='密码';
$language['USER_STYLE']='风格';
$language['USER_LANGUE']='语言';
$language['IMAGE_CODE']='验证码';
$language['INSERT_USERNAME']='你必须输入用户名!';
$language['INSERT_PASSWORD']='你必须输入密码!';
$language['DIF_PASSWORDS']='该密码不能匹配!';
$language['ERR_NO_EMAIL']='你必须输入一个有效的 email 位址';
$language['USER_EMAIL_AGAIN']='重覆 email';
$language['ERR_NO_EMAIL_AGAIN']='重覆 email';
$language['DIF_EMAIL']='该 emails 不能匹配!';
$language['SECURITY_CODE']='回答该问题';
# Password strength
$language['WEEK']='弱';
$language['MEDIUM']='中';
$language['SAFE']='安全';
$language['STRONG']='强';
?>