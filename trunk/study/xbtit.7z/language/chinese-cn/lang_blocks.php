<?php
$language['BLOCK_USER']='用户讯息';
$language['BLOCK_INFO']='Tracker 信息';
$language['BLOCK_MENU']='主菜单';
$language['BLOCK_CLOCK']='时钟';
$language['BLOCK_FORUM']='论坛';
$language['BLOCK_LASTMEMBER']='最新会员';
$language['BLOCK_ONLINE']='线上';
$language['BLOCK_ONTODAY']='今天';
$language['BLOCK_SHOUTBOX']='交流厅';
$language['BLOCK_TOPTORRENTS']='热门种子';
$language['BLOCK_LASTTORRENTS']='最新上传';
$language['BLOCK_NEWS']='新闻';
$language['BLOCK_SERVERLOAD']='伺服负载';
$language['BLOCK_POLL']='投票';
$language['BLOCK_SEEDWANTED']='需补种';
$language['BLOCK_PAYPAL']='赞助';
$language['BLOCK_MAINTRACKERTOOLBAR']='Tracker工具栏';
$language['BLOCK_MAINUSERTOOLBAR']='用户工具栏';
$language['WELCOME_LASTUSER']=' 欢迎参观我的站台 ';
$language['BLOCK_MINCLASSVIEW']='最低权限能浏览';
$language['BLOCK_MAXCLASSVIEW']='最高权限能浏览';
?>