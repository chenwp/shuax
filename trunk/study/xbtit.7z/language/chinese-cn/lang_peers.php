<?php
$language['PEER_PROGRESS']='进度';
$language['PEER_COUNTRY']='国家';
$language['PEER_PORT']='端口';
$language['PEER_STATUS']='状态';
$language['PEER_CLIENT']='客户端';
$language['NO_PEERS']='没有用户';
?>