<?php
$language['DELETE_READED']='删除';
$language['USER_LANGUE']='语言';
$language['USER_STYLE']='风格';
$language['CURRENTLY_PEER']='你目前做种或吸血的种子';
$language['STOP_PEER']='你必须停止你的客户端';
$language['USER_PWD_AGAIN']='重复密码';
$language['EMAIL_FAILED']='发送email已失败!';
$language['NO_SUBJECT']='无主题';
$language['MUST_ENTER_PASSWORD']='<br /><font color="#FF0000"><strong>您必须输入密码,才可修改上述设置.</strong></font>';
$language['ERR_PASS_WRONG']='未输入密码或输入密码错误,您不能修改您的资料.';
$language['MSG_DEL_ALL_PM']='如果您选取未读的短消息,他们不会被删除';
$language['ERR_PM_GUEST']='抱歉,你不能发送短消息给访客或自已!';
?>