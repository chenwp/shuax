<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "kswsungjira";
$database = "free";
$TABLE_PREFIX = "xbtit_";

?>