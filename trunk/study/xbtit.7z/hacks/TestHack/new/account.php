<?php

if (!defined("IN_BTIT"))
      die("non direct access!");


?>