<?php
$design_copyright='<a href="http://www.stonept.org" target="_blank">石头PT</a>';
?>