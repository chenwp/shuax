Windsoul++ simple demo :)

This Demo need 4M Video Ram (Support 565 hi-color mode is better) and a MMX CPU

PageUp PageDown Home End --- hero walk
Space -- hero stop
MOuse Left Button --- Decrease flying object
F1 ---  (1024x768 / 640x480)

http://member.netease.com/~cloudwu/
cloudwu@263.net