#include <stdio.h>
#include <string.h>
#include "xmlParser.cpp"

int main(int argc, char **argv)
{
	/*��ȡ��ǰʹ�õ�Ƥ��*/
	char UserName[256];
	char DataPath[256];
	DWORD len = 255;
	GetUserName(UserName, &len);
	OSVERSIONINFO info;
	info.dwOSVersionInfoSize = sizeof(info);
	GetVersionEx(&info);
	if (info.dwMajorVersion < 6) //xp
	{
		wsprintf(DataPath, "C:\\Users\\%s\\Application Data\\Tencent\\QQMusic\\Option2.xml", UserName);
	}
	else //vista or higher
	{
		wsprintf(DataPath, "C:\\Users\\%s\\AppData\\Roaming\\Tencent\\QQMusic\\Option2.xml", UserName);
	}
	XMLNode Option = XMLNode::openFileHelper(DataPath, "QQMusicOption");
	char config[256];
	char conbak[256];
	strcpy(config, Option.getChildNode("Skins").getAttribute("currentPath"));
	strcat(config, "\\List\\config.xml");
	strcpy(conbak, config);
	strcat(conbak, ".bak");
	/*��Ƥ�����ý����޸�*/
	XMLNode xMainNode = XMLNode::openFileHelper(config, "theme");
	xMainNode.writeToFile(conbak, "gb2312");
	XMLNode xNode = xMainNode.getChildNode("Window");
	int n = xNode.nChildNode("DlgItem");
	int i, my1, my2;
	int height;
	char buf[64];
	for (i = 0, my1 = 0; i < n; i++)
	{
		XMLNode x = xNode.getChildNode("DlgItem", &my1);
		if (stricmp(x.getAttribute("id"), "DlgItem_Advertisement") == 0)
		{
			height = atoi(x.getAttribute("height"));
			x.updateAttribute("0", NULL, "height");
		}
	}
	for (i = 0, my2 = 0; i < n; i++)
	{
		XMLNode x = xNode.getChildNode("DlgItem", &my2);
		if (strstr(x.getAttribute("id"), "List") != 0)
		{
			int oldheight = atoi(x.getAttribute("height"));
			itoa(oldheight + height, buf, 10);
			x.updateAttribute(buf, NULL, "height");
		}
	}
	xMainNode.writeToFile(config, "gb2312");
	MessageBoxW(0, L"��ϲ�㣬�����Ѿ���ɡ����¿���QQ���ְɡ�", L"ˣ��-QQ����2009ȥ��湤��", MB_OK);
	return 0;
}